#!/home/sluggish/career_recommendation_venv/bin/python
print("Hello from test script")
