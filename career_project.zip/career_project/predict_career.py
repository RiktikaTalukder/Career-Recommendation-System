import sys
import os
import json
from pathlib import Path
import numpy as np
import joblib
from google import genai

def get_gemini_explanation(careers, skills_with_scores, group):
    """Get personalized, short, 'you'-focused career explanations from Gemini."""
    try:
        client = genai.Client()  # Needs GOOGLE_API_KEY in environment

        skills_str = ', '.join(skills_with_scores)

        # BAD vs GOOD examples for each group
        examples = {
            "stem": (
                "BAD EXAMPLE (do not copy):\n"
                "A Mechanical Engineer designs, builds, and tests machines and devices. Strong technical and analytical skills are required.\n\n"
                "GOOD EXAMPLE (copy this style exactly):\n"
                "You have a strong technical mindset and enjoy solving complex problems, which makes you a great fit for Mechanical Engineering. Your curiosity and creativity will help you tackle challenging projects with confidence. If you work on building your communication skills, you’ll be able to explain your ideas even better. Stay curious and keep learning—Mechanical Engineering will reward your efforts!"
            ),
            "bus": (
                "BAD EXAMPLE (do not copy):\n"
                "Marketing Managers create strategies to promote products and lead marketing teams. Leadership and communication are important skills.\n\n"
                "GOOD EXAMPLE (copy this style exactly):\n"
                "You have a creative spirit and a natural ability to lead, which makes you well-suited for marketing management. Your communication skills will help you inspire teams and connect with clients. Focusing on developing your analytical skills can make your campaigns even more effective. Believe in your ideas and keep pushing boundaries—marketing is a space where you can shine."
            ),
            "hum": (
                "BAD EXAMPLE (do not copy):\n"
                "Social Workers support people in need and help them solve problems. Empathy and communication are required.\n\n"
                "GOOD EXAMPLE (copy this style exactly):\n"
                "You truly care about others and know how to listen, which makes you perfect for social work. Your empathy allows you to connect deeply with people and offer real support. By developing your research skills, you’ll be able to help even more effectively. Trust your compassion—you have what it takes to make a real difference for others."
            )
        }

        # Pick group-specific example
        example = examples.get(group, "")

        prompt = f"""
You are a warm and encouraging career advisor speaking directly to a student.

The student completed a 15-question quiz, and their skill ratings are:
{skills_str}

Based on these, we recommended the following top 3 careers:
1. {careers[0]}
2. {careers[1]}
3. {careers[2]}

For each career, write 2 to 3 very short paragraphs (3-5 sentences each) that:

- Highlight the student's key strengths and how these align with the career.
- Gently mention any skill areas that could be improved relevant to the career.
- Explain why this career is a good fit for them personally.
- Use a friendly, motivating tone, speaking directly to the student as "you".
- Avoid repeating the skills list verbatim; integrate them naturally.
- Keep the overall explanation concise and easy to read.

Do not use bullet points or lists. Focus on clarity and encouragement.
"""


        response = client.generate_text(
            model="gemini-2.5-turbo",
            prompt=prompt,
            temperature=0.3
        )
        return response.text.strip()

    except Exception as e:
        return f"Could not generate explanation: {str(e)}"

def aggregate_scores_to_skills(group, scores):
    group_skills_map = {
        "stem": ["Analytical", "Technical", "Problem-solving", "Research", "Creative", "Communication", "Leadership"],
        "bus": ["Analytical", "Communication", "Leadership", "Financial Acumen", "Strategic Thinking", "Creative", "Negotiation"],
        "hum": ["Communication", "Empathy", "Research", "Critical Thinking", "Writing", "Collaboration", "Ethical Reasoning"]
    }
    if group not in group_skills_map:
        raise ValueError(f"Invalid group: {group}")
    skills = group_skills_map[group]
    scores_list = scores.tolist()
    group_sizes = [2, 2, 2, 2, 2, 3, 2]  # total 15
    grouped_scores = []
    idx = 0
    for size in group_sizes:
        group_slice = scores_list[idx:idx + size]
        avg_score = sum(group_slice) / len(group_slice) if group_slice else 0
        grouped_scores.append(avg_score)
        idx += size
    return [f"{skill} ({score:.1f}/10)" for skill, score in zip(skills, grouped_scores)]

def main():
    try:
        SCRIPT_DIR = Path(__file__).parent.resolve()
        if len(sys.argv) != 32:
            raise ValueError(f"Expected 31 arguments, got {len(sys.argv) - 1}")
        group = sys.argv[1]
        scores = np.array([float(x) for x in sys.argv[2:17]])
        weights = np.array([float(x) for x in sys.argv[17:32]])
        weighted_scores = scores * weights

        # Load ML models
        models_dir = SCRIPT_DIR / "models"
        model = joblib.load(models_dir / f"{group}_model.pkl")
        scaler = joblib.load(models_dir / f"{group}_scaler.pkl")
        encoder = joblib.load(models_dir / f"{group}_encoder.pkl")

        # Predict
        scaled = scaler.transform([weighted_scores])
        proba = model.predict_proba(scaled)[0]
        top3_indices = np.argsort(proba)[-3:][::-1]
        top3_careers = encoder.inverse_transform(top3_indices).tolist()

        # Skills for explanation
        skills_with_scores = aggregate_scores_to_skills(group, scores)

        # Get explanation from Gemini
        explanation = get_gemini_explanation(top3_careers, skills_with_scores, group)

        result = {
            "top3": top3_careers,
            "probabilities": [float(proba[i]) for i in top3_indices],
            "explanation": explanation
        }
        print(json.dumps(result))

    except Exception as e:
        error = {"error": str(e), "type": type(e).__name__}
        print(json.dumps(error), file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()