<?php


// Load composer dependencies (with better error handling)
$autoloadPath = __DIR__ . '/vendor/autoload.php';
if (!file_exists($autoloadPath)) {
    die("Error: Composer dependencies not found. Run 'composer install' in your project directory.");
}
require $autoloadPath;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;

function callGeminiAPI(string $prompt): string
{
    // Get API key with fallback to .env file
    $apiKey = getenv('GEMINI_API_KEY');

    if (!$apiKey && file_exists(__DIR__ . '/.env')) {
        $dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
        $dotenv->load();
        $apiKey = $_ENV['GEMINI_API_KEY'] ?? getenv('GEMINI_API_KEY');
    }

    if (!$apiKey) {
        throw new RuntimeException(
            'GEMINI_API_KEY not set. ' .
            'Please set it in your environment variables or .env file'
        );
    }

    $client = new Client([
        'base_uri' => 'https://generativelanguage.googleapis.com/v1beta/',
        'timeout' => 30.0,  // Add timeout
    ]);

    try {
        $response = $client->post("models/gemini-2.5-flash:generateContent", [
            'query' => ['key' => $apiKey],
            'json' => [
                'contents' => [
                    [
                        'parts' => [
                            ['text' => $prompt]
                        ]
                    ]
                ]
            ],
            'http_errors' => false
        ]);


        $data = json_decode($response->getBody(), true);

        // More robust response parsing
        if ($response->getStatusCode() !== 200) {
            return "API Error: HTTP {$response->getStatusCode()} - " .
                ($data['error']['message'] ?? 'Unknown error');
        }

        return $data['candidates'][0]['content']['parts'][0]['text'] ??
            'No response content found';

    } catch (RequestException $e) {
        return "API Connection Error: " . $e->getMessage();
    } catch (Exception $e) {
        return "Error: " . $e->getMessage();
    }
}