<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "<pre>";
$cmd = '/home/sluggish/career_recommendation_venv/bin/python /opt/lampp/htdocs/career_project/test.py 2>&1';
$output = shell_exec($cmd);
if ($output === null) {
    echo "shell_exec returned null.";
} else {
    echo $output;
}
echo "</pre>";
?>
