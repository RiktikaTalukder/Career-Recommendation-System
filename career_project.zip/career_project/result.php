<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once __DIR__ . '/gemini_client.php'; // Include the Gemini API function

// Redirect if session data missing
if (!isset($_SESSION['result']) || !isset($_SESSION['group']) || !isset($_SESSION['skills'])) {
    header("Location: index.php");
    exit;
}

$result = $_SESSION['result'];
$group = $_SESSION['group'];
$skills = $_SESSION['skills'];

// Build skill description for prompt
$skillDescriptions = [];
foreach ($skills as $skill => $level) {
    $skillDescriptions[] = ucfirst(str_replace('_', ' ', $skill)) . ": $level";
}
$skillText = implode(", ", $skillDescriptions);

// Optional: Clear session data after reading to avoid stale results on refresh
unset($_SESSION['result']);
unset($_SESSION['group']);
unset($_SESSION['skills']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Career Recommendations</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="style.css" />

</head>

<body>
    <div class="container">
        <h1>Your Career Recommendations</h1>

        <?php if (!empty($result["top3"]) && is_array($result["top3"])): ?>
            <div class="results-box">
                <ol>
                    <?php foreach ($result["top3"] as $index => $career): 
                        // Generate explanation for each career
                        $prompt = "Explain in 100 words why someone with these skills ($skillText) would be well-suited for a career as $career in the $group field. Include key responsibilities and required skills.";
                        $explanation = callGeminiAPI($prompt);
                    ?>
                        <li class="career-item">
                            <strong><?= htmlspecialchars($career) ?></strong>
                            
                            <div class="career-details">
                                <p><?= htmlspecialchars($explanation) ?></p>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ol>
            </div>
        <?php else: ?>
            <div class="error-box">
                <p>Error: Could not retrieve valid results.</p>
                <pre><?= htmlspecialchars(json_encode($result, JSON_PRETTY_PRINT)) ?></pre>
            </div>
        <?php endif; ?>

        <a href="index.php" class="retake-btn">Take the quiz again</a>
    </div>
</body>
</html>
