#!/usr/bin/env python3
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

CAREER_EXPLANATIONS = {
    "stem": {
        "Software Engineer": "Recommended because of your strong analytical problem-solving skills and comfort with logical systems and programming concepts.",
        "Data Scientist": "Recommended due to your excellent quantitative skills, ability to work with complex data, and strong analytical thinking.",
        "Mechanical Engineer": "Recommended based on your strong spatial reasoning, problem-solving with physical systems, and comfort with technical concepts.",
        "Electrical Engineer": "Recommended because of your aptitude for mathematical concepts, logical thinking, and interest in how electrical systems function.",
        "Civil Engineer": "Recommended based on your strong analytical skills, ability to solve structural problems, and attention to technical details.",
        "Architect": "Recommended due to your combination of technical skills, spatial reasoning, and creative problem-solving abilities.",
        "Doctor": "Recommended because of your strong analytical abilities, scientific curiosity, and capacity to handle complex biological systems.",
        "Nurse": "Recommended based on your combination of technical skills, problem-solving in clinical contexts, and ability to work under pressure.",
        "Scientist": "Recommended due to your strong analytical thinking, curiosity about how things work, and ability to conduct systematic research.",
        "Researcher": "Recommended because of your excellent problem-solving skills, analytical thinking, and ability to work with complex information."
    },
    "business": {
        "Entrepreneur": "Recommended based on your creative problem-solving skills, ability to analyze market opportunities, and comfort with risk assessment.",
        "Business Analyst": "Recommended due to your strong analytical skills, ability to interpret business data, and structured problem-solving approach.",
        "Investment Banker": "Recommended because of your excellent quantitative skills, ability to analyze financial data, and comfort with high-pressure decisions.",
        "Finance Officer": "Recommended based on your strong numerical aptitude, analytical thinking, and ability to interpret financial information.",
        "Accountant": "Recommended due to your attention to detail, strong numerical skills, and ability to work with structured financial data.",
        "Marketing Manager": "Recommended because of your analytical skills combined with creativity in interpreting market data and consumer behavior.",
        "Human Resources Manager": "Recommended based on your strong interpersonal analysis skills and ability to solve organizational problems systematically.",
        "Management Consultant": "Recommended due to your excellent problem-solving skills, analytical thinking, and ability to structure business solutions.",
        "Real Estate Analyst": "Recommended because of your strong analytical skills, ability to evaluate market data, and comfort with financial calculations.",
        "Researcher": "Recommended based on your analytical thinking, ability to interpret complex information, and structured approach to problems."
    },
    "humanities": {
        "Journalist": "Recommended because of your strong communication skills, ability to analyze complex information, and structured thinking.",
        "Lawyer": "Recommended based on your excellent analytical reasoning, logical thinking, and ability to structure complex arguments.",
        "Social Worker": "Recommended due to your strong interpersonal analysis skills and ability to solve human problems systematically.",
        "Anthropologist": "Recommended because of your analytical approach to understanding human behavior and cultural systems.",
        "Political Scientist": "Recommended based on your ability to analyze complex systems, interpret data, and think critically about social structures.",
        "Civil Servant": "Recommended due to your structured thinking, analytical approach to policy problems, and systematic reasoning.",
        "Public Relations Specialist": "Recommended because of your analytical approach to communication problems and ability to structure messaging.",
        "Sociologist": "Recommended based on your ability to analyze social systems, interpret complex data, and think critically about human behavior.",
        "Psychologist": "Recommended due to your analytical approach to understanding human behavior and problem-solving in interpersonal contexts.",
        "Researcher": "Recommended because of your strong analytical thinking, ability to work with complex information, and structured reasoning."
    }
}

@app.route('/explain', methods=['POST'])
def explain_career():
    try:
        data = request.get_json()
        if not data or 'group' not in data or 'career' not in data:
            return jsonify({"error": "Missing group or career"}), 400
            
        explanation = CAREER_EXPLANATIONS.get(data['group'], {}).get(data['career'], "")
        if not explanation:
            explanation = f"This career matches your skills and abilities based on your assessment results."
            
        return jsonify({"explanation": explanation})
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)