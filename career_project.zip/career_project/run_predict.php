<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Example inputs (replace with actual data)
$group = 'stem';
$scores = array_fill(0, 15, 0.5);
$weights = array_fill(0, 15, 1);

$escaped_args = array_map('escapeshellarg', array_merge([$group], $scores, $weights));

$python = '/home/sluggish/career_recommendation_venv/bin/python';
$script = '/opt/lampp/htdocs/career_project/predict_career.py';

// Build command with LD_PRELOAD to fix libstdc++ conflict
$cmd = "LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libstdc++.so.6 " . escapeshellcmd($python) . " " . escapeshellarg($script) . " " . implode(' ', $escaped_args) . " 2>&1";

echo "<pre>Running command:\n$cmd\n\n";

$output = shell_exec($cmd);

echo "Output:\n$output\n</pre>";
$json_start = strpos($output, '{');
if ($json_start !== false) {
    $json_output = substr($output, $json_start);
    $result = json_decode($json_output, true);
    if ($result === null) {
        echo "<pre>Invalid JSON output:\n$output</pre>";
    } elseif (isset($result['error'])) {
        echo "<pre>Python error: " . htmlspecialchars($result['error']) . "</pre>";
    } else {
        echo "<h2>Top 3 Career Predictions</h2><ul>";
        foreach ($result['top3'] as $i => $career) {
            $prob = number_format($result['probabilities'][$i] * 100, 2);
            echo "<li>{$career} — Probability: {$prob}%</li>";
        }
        echo "</ul>";
    }
} else {
    echo "<pre>Could not find JSON output:\n$output</pre>";
}
$json_start = strpos($output, '{');
if ($json_start !== false) {
    $json_output = substr($output, $json_start);
    $result = json_decode($json_output, true);
    if ($result === null) {
        echo "<pre>Invalid JSON output:\n$output</pre>";
    } elseif (isset($result['error'])) {
        echo "<pre>Python error: " . htmlspecialchars($result['error']) . "</pre>";
    } else {
        echo "<h2>Top 3 Career Predictions</h2><ul>";
        foreach ($result['top3'] as $i => $career) {
            $prob = number_format($result['probabilities'][$i] * 100, 2);
            echo "<li>{$career} — Probability: {$prob}%</li>";
        }
        echo "</ul>";
    }
} else {
    echo "<pre>Could not find JSON output:\n$output</pre>";
}
?>
