<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $group = $_POST['group'] ?? null;

    // Validate group selection
    if ($group && in_array($group, ['stem', 'business', 'humanities'])) {
        $scores = [];
        $weights = [];

        // Validate and collect scores and weights
        for ($i = 1; $i <= 15; $i++) {
            $score_key = "q$i";
            $weight_key = "w$i";

            if (!isset($_POST[$score_key])) {
                die("<p class='error'>Missing answer for question $i.</p>");
            }

            $score = intval($_POST[$score_key]);
            if ($score < 0 || $score > 10) {
                die("<p class='error'>Score for question $i must be between 0 and 10.</p>");
            }
            $scores[] = $score;

            $weight = floatval($_POST[$weight_key] ?? 1.0);
            $weights[] = $weight;
        }

        // Map group to model prefix used in Python script
        $group_key = ($group === "business") ? "bus" : (($group === "humanities") ? "hum" : "stem");

        // Prepare Python command
        $python_path = '/home/sluggish/career_recommendation_venv/bin/python';
        $script_path = '/opt/lampp/htdocs/career_project/predict_career.py';
        $args = array_merge([$group_key], $scores, $weights);
        $escaped_args = array_map('escapeshellarg', $args);
        $cmd = "LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libstdc++.so.6 " . escapeshellcmd($python_path) . " " . escapeshellarg($script_path) . " " . implode(' ', $escaped_args) . " 2>&1";

        // Execute Python script and capture output
        $output = shell_exec($cmd);

        // Extract JSON part from output
        $json_start = strpos($output, '{');
        if ($json_start !== false) {
            $json_output = substr($output, $json_start);
            $result = json_decode($json_output, true);
        } else {
            $result = null;
        }

        // Handle JSON decode errors or invalid output
        if ($result === null || json_last_error() !== JSON_ERROR_NONE) {
            echo "<div class='error'>";
            echo "<h2>Error Processing Results</h2>";
            echo "<pre>Command: " . htmlspecialchars($cmd) . "</pre>";
            echo "<pre>Output:\n" . htmlspecialchars($output) . "</pre>";
            echo "<pre>JSON decode error: " . json_last_error_msg() . "</pre>";
            echo "</div>";
            exit;
        }

        // Check if result contains expected data
        if (isset($result["top3"])) {
            $_SESSION['result'] = $result;
            $_SESSION['group'] = $group;

            // Add dummy skills data or replace with actual user skill input if available
            $_SESSION['skills'] = [
                'analytical' => 'high',
                'creative' => 'medium',
                'technical' => 'high',
                'communication' => 'medium',
                'leadership' => 'low',
                'research' => 'medium',
                'problem_solving' => 'high'
            ];

            // Redirect to results page
            header("Location: result.php");
            exit;
        } else {
            echo "<div class='error'>";
            echo "<h2>Error: Invalid result structure</h2>";
            echo "<pre>Command: " . htmlspecialchars($cmd) . "</pre>";
            echo "<pre>Output:\n" . htmlspecialchars($output) . "</pre>";
            echo "</div>";
            exit;
        }
    } else {
        echo "<p class='error'>Invalid group selected.</p>";
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Career Recommendation Quiz</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="style.css" />

</head>

<body>
    <div class="container">
        <h1>🎓 Welcome to the Career Recommendation Quiz</h1>

        <form id="groupForm">
            <label>Select Your Interest Group:</label><br />
            <div class="radio-group">
                <label><input type="radio" name="group" value="stem" required /> STEM</label>
                <label><input type="radio" name="group" value="business" /> Business</label>
                <label><input type="radio" name="group" value="humanities" /> Humanities</label>
            </div>
            <button type="button" onclick="showQuestions()">Next</button>
        </form>

        <form id="quizForm" method="POST" style="display:none;">
            <div id="questionsContainer"></div>
            <input type="hidden" name="group" id="groupInput" />
            <button type="submit">Submit Answers</button>
        </form>
    </div>

    <script>
        const questions = {
            stem: [
                { text: "How much do you enjoy solving complex problems that require logical or structured thinking?", weight: 1.3 },
                { text: "How interested are you in learning how systems (biological, technical, structural, or digital) function?", weight: 1.2 },
                { text: "How comfortable are you working with numbers, equations, or quantitative data?", weight: 1.1 },
                { text: "How much do you enjoy working with tools, instruments, or machines (digital or physical)?", weight: 1.0 },
                { text: "How curious are you about understanding why things work, not just how to use them?", weight: 1.2 },
                { text: "How interested are you in designing or building things (e.g., products, structures, code, experiments)?", weight: 1.1 },
                { text: "How motivated are you to keep learning new things throughout your entire career?", weight: 1.0 },
                { text: "How much do you enjoy writing reports, documenting processes, or explaining your findings?", weight: 0.9 },
                { text: "How comfortable are you with working in teams to solve problems or complete tasks?", weight: 0.8 },
                { text: "How well do you handle high-pressure or time-sensitive situations?", weight: 0.9 },
                { text: "How interested are you in careers where your work can impact people's lives directly?", weight: 1.0 },
                { text: "How much do you enjoy using software or digital tools to complete tasks or analyze data?", weight: 1.1 },
                { text: "How comfortable are you with following strict procedures, standards, or protocols?", weight: 0.8 },
                { text: "How willing are you to spend long hours focused on a single problem or project?", weight: 0.9 },
                { text: "How much do you value innovation and discovering new solutions to unsolved problems?", weight: 1.2 }
            ],
            business: [
                { text: "How comfortable are you working with numbers, budgets, or financial data?", weight: 1.2 },
                { text: "How much do you enjoy analyzing business problems and proposing structured solutions?", weight: 1.3 },
                { text: "How comfortable are you communicating ideas clearly, both in writing and verbally?", weight: 1.1 },
                { text: "How interested are you in understanding how markets, businesses, and economies work?", weight: 1.2 },
                { text: "How well do you work with deadlines, pressure, or high-stakes decision-making?", weight: 1.0 },
                { text: "How much do you enjoy managing or coordinating teams or people?", weight: 1.0 },
                { text: "How comfortable are you with interpreting graphs, charts, and data dashboards?", weight: 1.1 },
                { text: "How confident are you in your ability to persuade or influence others?", weight: 0.9 },
                { text: "How interested are you in roles that require strong attention to detail and documentation?", weight: 0.8 },
                { text: "How willing are you to continuously learn new business tools, software, or models?", weight: 0.9 },
                { text: "How important is creativity in your approach to problem-solving?", weight: 0.8 },
                { text: "How much do you enjoy identifying trends or patterns in data to make strategic decisions?", weight: 1.1 },
                { text: "How well do you handle risk or uncertainty in business decisions?", weight: 1.0 },
                { text: "How much do you enjoy presenting findings or proposals to teams or stakeholders?", weight: 0.9 },
                { text: "How strongly do you prefer a structured work environment over a dynamic or unpredictable one?", weight: 0.8 }
            ],
            humanities: [
                { text: "How comfortable are you with reading, writing, and interpreting complex texts or ideas?", weight: 1.3 },
                { text: "How much do you enjoy learning about people, societies, cultures, or communities?", weight: 1.2 },
                { text: "How interested are you in understanding and improving social, political, or legal systems?", weight: 1.1 },
                { text: "How strong are your verbal communication and storytelling skills?", weight: 1.0 },
                { text: "How comfortable are you with public speaking or debating?", weight: 0.9 },
                { text: "How empathetic are you when working with people in vulnerable or complex life situations?", weight: 1.0 },
                { text: "How curious are you about human behavior, history, or cultural differences?", weight: 1.1 },
                { text: "How much do you enjoy solving social, ethical, or interpersonal problems?", weight: 1.0 },
                { text: "How willing are you to listen actively and understand different perspectives before making decisions?", weight: 0.9 },
                { text: "How important is it to you that your work contributes to the betterment of society?", weight: 1.0 },
                { text: "How strong are your research and information-gathering skills?", weight: 1.1 },
                { text: "How comfortable are you with writing detailed reports, papers, or documentation?", weight: 0.9 },
                { text: "How interested are you in analyzing societal trends, public behavior, or policy impacts?", weight: 1.0 },
                { text: "How confident are you in handling emotionally sensitive or ethically complex situations?", weight: 0.9 },
                { text: "How open are you to working in roles that involve collaboration, negotiation, or diplomacy?", weight: 0.8 }
            ]
        };

        function showQuestions() {
            const group = document.querySelector('input[name="group"]:checked').value;
            const container = document.getElementById("questionsContainer");
            document.getElementById("groupInput").value = group;
            document.getElementById("groupForm").style.display = "none";

            container.innerHTML = "";
            questions[group].forEach((q, i) => {
                container.innerHTML += `
                    <div class="question">
                        <label>${i + 1}. ${q.text}</label>
                        <span class="weight">(Weight: ${q.weight})</span><br />
                        <input type="number" name="q${i + 1}" min="0" max="10" required />
                        <input type="hidden" name="w${i + 1}" value="${q.weight}" />
                    </div>
                `;
            });

            document.getElementById("quizForm").style.display = "block";
        }

        document.getElementById("quizForm").addEventListener("submit", function (e) {
            const inputs = document.querySelectorAll("#questionsContainer input[type='number']");
            let valid = true;

            inputs.forEach(input => {
                if (input.value === "" || input.value < 0 || input.value > 10) {
                    input.style.border = "1px solid red";
                    valid = false;
                }
            });

            if (!valid) {
                e.preventDefault();
                alert("Please answer all questions with values between 0-10!");
            }
        });
    </script>
</body>

</html>
